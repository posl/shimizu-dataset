package spark.examples.exception;

public class SubclassOfBaseException extends BaseException {
    private static final long serialVersionUID = 1L;
}
