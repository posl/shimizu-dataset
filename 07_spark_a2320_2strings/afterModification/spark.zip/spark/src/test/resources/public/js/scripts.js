console.log("Hello JavaScript");
