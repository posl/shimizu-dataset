package com.github.davidmoten.rx.jdbc.tuple;

import org.junit.Test;

import com.github.davidmoten.junit.Asserts;

public class TuplesTest {

    @Test
    public void testTuplesInstantiationForCoverage() {
        Asserts.assertIsUtilityClass(Tuples.class);
    }
}
