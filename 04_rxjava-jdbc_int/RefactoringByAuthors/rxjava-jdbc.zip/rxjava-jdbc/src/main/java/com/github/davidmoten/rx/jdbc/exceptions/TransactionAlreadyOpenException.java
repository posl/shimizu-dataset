package com.github.davidmoten.rx.jdbc.exceptions;

public class TransactionAlreadyOpenException extends RuntimeException {

    private static final long serialVersionUID = -6236375317371028941L;

    public TransactionAlreadyOpenException() {
        super();
    }

}
