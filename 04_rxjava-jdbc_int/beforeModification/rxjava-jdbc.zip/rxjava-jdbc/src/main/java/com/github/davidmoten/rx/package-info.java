/**
 * Utilities for use with RxJava.
 */
package com.github.davidmoten.rx;