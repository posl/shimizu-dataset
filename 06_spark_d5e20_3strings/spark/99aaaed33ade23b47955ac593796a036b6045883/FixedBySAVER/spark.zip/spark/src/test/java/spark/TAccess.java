package spark;

public class TAccess {

    public static void clearRoutes() {
        Spark.clearRoutes();
    }
    
    public static void stop() {
    	Spark.stop();
    }
    
}
