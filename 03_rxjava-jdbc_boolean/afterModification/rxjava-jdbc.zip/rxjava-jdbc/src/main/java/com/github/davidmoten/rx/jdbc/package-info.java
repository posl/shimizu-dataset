/**
 * Database querying utilities for use with JDBC and RxJava.
 */
package com.github.davidmoten.rx.jdbc;