package com.github.davidmoten.rx.jdbc;

import org.junit.Test;

public class QueriesTest {

    @Test
    public void obtainCoverageOfPrivateConstructor() {
        TestingUtil.instantiateUsingPrivateConstructor(Queries.class);
    }

}
