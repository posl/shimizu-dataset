package com.github.davidmoten.rx.jdbc;

public class DatabaseSyncTest extends DatabaseTestBase {

    public DatabaseSyncTest() {
        super(false);
    }

}
