package spoon.test.strings;

public class Main {

	public static void main(String[] args) {
		
		System.out.println("a"+"b");
		
	}
	
}
