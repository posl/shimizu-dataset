package spoon.test.limits;

import spoon.test.limits.utils.ContainInternalClass;

public class MultipleInternalClass {
	ContainInternalClass.InternalClass test;
	ContainInternalClass.InternalClass.InsideInternalClass toto;
}
