package spoon.test.control;

public class DoWhile {

	public void methode(){
		int i =0;
		do
			i++;
		while (i<5);
	}
}
