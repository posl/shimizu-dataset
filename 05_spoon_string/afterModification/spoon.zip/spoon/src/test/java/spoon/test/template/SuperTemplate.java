package spoon.test.template;

import spoon.template.Template;

public class SuperTemplate implements Template {

	public void toBeOverriden() {
	}
	
}
