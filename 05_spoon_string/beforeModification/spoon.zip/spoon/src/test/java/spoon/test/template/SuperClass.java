package spoon.test.template;

public class SuperClass {

}
