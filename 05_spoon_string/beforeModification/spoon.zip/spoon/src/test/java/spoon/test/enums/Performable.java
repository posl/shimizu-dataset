package spoon.test.enums;

import java.util.Stack;

public interface Performable {
    void perform( Stack<Integer> s, int[] op );
}
