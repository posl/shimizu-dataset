package spoon.test.generics;

public class SimilarSignatureMethodes {
	
	public <E extends java.lang.Throwable> void methode(E arg) {
		
	}
	
	public <E extends java.lang.Object> void methode(E arg) {
	}
}

