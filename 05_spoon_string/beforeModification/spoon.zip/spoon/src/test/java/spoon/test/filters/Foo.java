package spoon.test.filters;

class Foo {
	int i;
	void foo() {
		int x = 3;
		int z;
		z= x+1;
		System.out.println(z);
	}
}

