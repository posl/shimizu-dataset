package spoon.test.limits.utils;

public class AccessibleClassFromNonAccessibleInterf implements NonAccessibleInterf {

	public void method(NonAccessibleInterf tmp) {
	}
}
