package spoon.test.template;

public class C1 {

	int[][][] myArray;
	
}
